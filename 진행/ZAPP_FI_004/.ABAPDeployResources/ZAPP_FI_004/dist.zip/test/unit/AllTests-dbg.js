sap.ui.define([
	"comsmilegate/zapp_fi_004/test/unit/controller/App.controller"
], function () {
	"use strict";
});
