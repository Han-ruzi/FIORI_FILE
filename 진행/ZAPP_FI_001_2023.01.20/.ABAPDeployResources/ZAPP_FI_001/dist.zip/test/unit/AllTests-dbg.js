sap.ui.define([
	"comsmilegate/zapp_fi_001/test/unit/controller/App.controller"
], function () {
	"use strict";
});
